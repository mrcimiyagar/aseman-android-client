package kasper.android.pulse.models.extras;

import java.io.Serializable;

public enum DocTypes implements Serializable {
    Photo,
    Audio,
    Video
}
