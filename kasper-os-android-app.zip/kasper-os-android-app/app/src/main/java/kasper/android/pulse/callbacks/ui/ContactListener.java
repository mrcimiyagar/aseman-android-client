package kasper.android.pulse.callbacks.ui;

import kasper.android.pulse.models.entities.Entities;

/**
 * Created by keyhan1376 on 5/31/2018.
 */

public interface ContactListener {
    void contactCreated(Entities.Contact contact);
}
