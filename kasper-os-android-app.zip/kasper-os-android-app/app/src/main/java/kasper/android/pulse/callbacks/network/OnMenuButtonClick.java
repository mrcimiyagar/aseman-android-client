package kasper.android.pulse.callbacks.network;

/**
 * Created by keyhan1376 on 5/8/2018.
 */

public interface OnMenuButtonClick {
    void menuButtonClicked();
}
