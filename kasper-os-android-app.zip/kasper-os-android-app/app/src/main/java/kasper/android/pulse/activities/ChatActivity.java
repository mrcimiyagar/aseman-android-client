package kasper.android.pulse.activities;

import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Handler;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.util.Pair;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.File;
import java.io.FileInputStream;
import java.util.Hashtable;
import java.util.List;
import java.util.Objects;

import kasper.android.pulse.R;
import kasper.android.pulse.adapters.MessagesAdapter;
import kasper.android.pulse.callbacks.network.OnFileUploadListener;
import kasper.android.pulse.callbacks.network.ServerCallback;
import kasper.android.pulse.callbacks.ui.OnFileSelectListener;
import kasper.android.pulse.extras.LinearDecoration;
import kasper.android.pulse.helpers.CallbackHelper;
import kasper.android.pulse.helpers.DatabaseHelper;
import kasper.android.pulse.helpers.GraphicHelper;
import kasper.android.pulse.models.entities.Entities;
import kasper.android.pulse.retrofit.MessageHandler;
import kasper.android.pulse.helpers.NetworkHelper;
import kasper.android.pulse.models.extras.DocTypes;
import kasper.android.pulse.models.extras.ProgressListener;
import kasper.android.pulse.models.network.Packet;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChatActivity extends AppCompatActivity {

    private long complexId;
    private long roomId;
    private long startFileId;

    RecyclerView chatRV;
    FloatingActionButton toBottomFAB;
    EditText chatET;
    ImageButton backBTN;
    ImageButton filesBTN;
    ImageButton sendBTN;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        if (getIntent().getExtras() != null) {
            complexId = getIntent().getExtras().getLong("complex_id");
            roomId = getIntent().getExtras().getLong("room_id");
            startFileId = getIntent().getExtras().getLong("start_file_id");
        }

        initViews();
        initDecorations();
        initListeners();
        initMessages();

        if (startFileId > 0) {
            new Handler().postDelayed(() -> {
                int pos = ((MessagesAdapter) Objects.requireNonNull(chatRV.getAdapter()))
                        .findFilePosition(startFileId);
                chatRV.smoothScrollToPosition(pos);
            }, 1000);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    private void initViews() {
        chatRV = findViewById(R.id.fragment_messages_recycler_view);
        toBottomFAB = findViewById(R.id.toBottomFAB);
        chatET = findViewById(R.id.fragment_messages_edit_text);
        backBTN = findViewById(R.id.fragment_messages_back_image_button);
        filesBTN = findViewById(R.id.fragment_messages_files_image_button);
        sendBTN = findViewById(R.id.fragment_messages_send_image_button);
    }

    private void initDecorations() {
        chatRV.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
        chatRV.addItemDecoration(new LinearDecoration(GraphicHelper.dpToPx(16), GraphicHelper.dpToPx(16)));
    }

    private void initListeners() {
        chatRV.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (((LinearLayoutManager) Objects.requireNonNull(chatRV.getLayoutManager()))
                        .findLastVisibleItemPosition() < Objects.requireNonNull(
                                chatRV.getAdapter()).getItemCount() - 5) {
                    toBottomFAB.animate().cancel();
                    toBottomFAB.animate().y(GraphicHelper.getScreenHeight()
                            - GraphicHelper.dpToPx(24) - GraphicHelper.dpToPx(72 + 56))
                            .setDuration(350).start();
                } else {
                    toBottomFAB.animate().cancel();
                    toBottomFAB.animate().y(GraphicHelper.getScreenHeight())
                            .setDuration(350).start();
                }
            }
        });
        toBottomFAB.setOnClickListener(view -> chatRV.smoothScrollToPosition(
                Objects.requireNonNull(chatRV.getAdapter()).getItemCount() - 1));
        backBTN.setOnClickListener(v -> onBackPressed());
        sendBTN.setOnClickListener(v -> {
            final String text = chatET.getText().toString();
            if (text.length() == 0) {
                Toast.makeText(ChatActivity.this, "Message text can not be null", Toast.LENGTH_SHORT).show();
                return;
            }
            final Pair<Entities.Message, Entities.MessageLocal> pair = DatabaseHelper.notifyTextMessageSending(roomId, text);
            final Entities.Message message = pair.first;
            final Entities.MessageLocal messageLocal = pair.second;
            final long messageLocalId = message.getMessageId();
            GraphicHelper.getMessageListener().messageSending(message, messageLocal);
            final Packet packet = new Packet();
            Entities.Complex complex = new Entities.Complex();
            complex.setComplexId(complexId);
            packet.setComplex(complex);
            Entities.Room room = new Entities.Room();
            room.setRoomId(roomId);
            packet.setRoom(room);
            packet.setTextMessage((Entities.TextMessage) message);
            MessageHandler messageHandler = NetworkHelper.getRetrofit().create(MessageHandler.class);
            Call<Packet> call = messageHandler.createTextMessage(packet);
            NetworkHelper.requestServer(call, new ServerCallback() {
                @Override
                public void onRequestSuccess(Packet packet) {
                    final Entities.TextMessage msg = packet.getTextMessage();
                    DatabaseHelper.notifyTextMessageSent(messageLocalId, msg.getMessageId(), msg.getTime());
                    GraphicHelper.getMessageListener().messageSent(messageLocalId, msg.getMessageId());
                }

                @Override
                public void onServerFailure() {
                    Toast.makeText(ChatActivity.this, "Message delivery failure", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onConnectionFailure() {
                    Toast.makeText(ChatActivity.this, "Message delivery failure", Toast.LENGTH_SHORT).show();
                }
            });
            chatET.setText("");
        });
        filesBTN.setOnClickListener(v -> {
            OnFileSelectListener selectListener = (path, docType) -> {
                String fileName = new File(path).getName();
                Entities.File file;
                Entities.FileLocal fileLocal;
                Entities.Message message;
                Entities.MessageLocal messageLocal;
                if (docType == DocTypes.Photo) {
                    try {
                        FileInputStream inputStream = new FileInputStream(new File(path));
                        BitmapFactory.Options bitmapOptions = new BitmapFactory.Options();
                        bitmapOptions.inJustDecodeBounds = true;
                        BitmapFactory.decodeStream(inputStream, null, bitmapOptions);
                        int imageWidth = bitmapOptions.outWidth;
                        int imageHeight = bitmapOptions.outHeight;
                        inputStream.close();
                        Pair<Entities.File, Entities.FileLocal> filePair = DatabaseHelper.notifyPhotoUploading(false, path, imageWidth, imageHeight);
                        file = filePair.first;
                        fileLocal = filePair.second;
                        Pair<Entities.Message, Entities.MessageLocal> msgPair = DatabaseHelper.notifyPhotoMessageSending(roomId, file.getFileId());
                        message = msgPair.first;
                        messageLocal = msgPair.second;
                    } catch (Exception ignored) {
                        message = null;
                        messageLocal = null;
                        file = null;
                        fileLocal = null;
                    }
                } else if (docType == DocTypes.Audio) {
                    Pair<Entities.File, Entities.FileLocal> filePair = DatabaseHelper.notifyAudioUploading(false, path, fileName, 60000);
                    file = filePair.first;
                    fileLocal = filePair.second;
                    Pair<Entities.Message, Entities.MessageLocal> msgPair = DatabaseHelper.notifyAudioMessageSending(roomId, file.getFileId());
                    message = msgPair.first;
                    messageLocal = msgPair.second;
                } else if (docType == DocTypes.Video) {
                    Pair<Entities.File, Entities.FileLocal> filePair = DatabaseHelper.notifyVideoUploading(false, path, fileName, 60000);
                    file = filePair.first;
                    fileLocal = filePair.second;
                    Pair<Entities.Message, Entities.MessageLocal> msgPair = DatabaseHelper.notifyVideoMessageSending(roomId, file.getFileId());
                    message = msgPair.first;
                    messageLocal = msgPair.second;
                } else {
                    file = null;
                    fileLocal = null;
                    message = null;
                    messageLocal = null;
                }

                final Entities.File finalFile = file;
                final Entities.Message finalMessage = message;
                final Entities.MessageLocal finalMessageLocal = messageLocal;

                GraphicHelper.getFileListener().fileUploading(docType, file, fileLocal);
                GraphicHelper.getMessageListener().messageSending(message, messageLocal);

                ProgressListener progressListener = progress -> {
                    if (finalFile != null) {
                        DatabaseHelper.notifyFileTransferProgressed(finalFile.getFileId(), progress);
                        GraphicHelper.runOnUiThread(() ->
                                GraphicHelper.getFileListener().fileTransferProgressed(docType
                                        , finalFile.getFileId(), progress));
                    }
                };

                OnFileUploadListener uploadListener = (OnFileUploadListener) (fileId, fileUsageId) -> {
                    if (finalFile != null) {
                        final long localFileId = finalFile.getFileId();
                        if (docType == DocTypes.Photo) {
                            DatabaseHelper.notifyPhotoUploaded(localFileId, fileId);
                        } else if (docType == DocTypes.Audio) {
                            DatabaseHelper.notifyAudioUploaded(localFileId, fileId);
                        } else if (docType == DocTypes.Video) {
                            DatabaseHelper.notifyVideoUploaded(localFileId, fileId);
                        }
                        DatabaseHelper.notifyUpdateMessageAfterFileUpload(finalMessage.getMessageId(), fileId, fileUsageId);
                        GraphicHelper.runOnUiThread(() -> {
                            GraphicHelper.getFileListener().fileUploaded(docType, localFileId, fileId);
                            Packet packet = new Packet();
                            Entities.Complex complex = new Entities.Complex();
                            complex.setComplexId(complexId);
                            packet.setComplex(complex);
                            Entities.Room room = new Entities.Room();
                            room.setRoomId(roomId);
                            packet.setRoom(room);
                            finalFile.setFileId(fileId);
                            packet.setFile(finalFile);
                            MessageHandler messageHandler = NetworkHelper.getRetrofit().create(MessageHandler.class);
                            Call<Packet> call = messageHandler.createFileMessage(packet);
                            NetworkHelper.requestServer(call, new ServerCallback() {
                                @Override
                                public void onRequestSuccess(Packet packet) {
                                    long messageId = -1;
                                    long time;
                                    if (docType == DocTypes.Photo) {
                                        messageId = packet.getPhotoMessage().getMessageId();
                                        time = packet.getPhotoMessage().getTime();
                                        DatabaseHelper.notifyPhotoMessageSent(finalMessageLocal.getMessageId(), messageId, time);
                                    } else if (docType == DocTypes.Audio) {
                                        messageId = packet.getAudioMessage().getMessageId();
                                        time = packet.getAudioMessage().getTime();
                                        DatabaseHelper.notifyAudioMessageSent(finalMessageLocal.getMessageId(), messageId, time);
                                    } else if (docType == DocTypes.Video) {
                                        messageId = packet.getVideoMessage().getMessageId();
                                        time = packet.getVideoMessage().getTime();
                                        DatabaseHelper.notifyVideoMessageSent(finalMessageLocal.getMessageId(), messageId, time);
                                    }
                                    GraphicHelper.getMessageListener().messageSent(finalMessageLocal.getMessageId(), messageId);
                                }

                                @Override
                                public void onServerFailure() {
                                    Toast.makeText(ChatActivity.this, "Message delivery failure", Toast.LENGTH_SHORT).show();
                                }

                                @Override
                                public void onConnectionFailure() {
                                    Toast.makeText(ChatActivity.this, "Message delivery failure", Toast.LENGTH_SHORT).show();
                                }
                            });
                        });
                    }
                };

                NetworkHelper.uploadFile(file, complexId, roomId, path, progressListener, uploadListener);
            };
            long selectCallbackId = CallbackHelper.register(selectListener);
            startActivity(new Intent(ChatActivity.this, FilesActivity.class)
                    .putExtra("select-callback", selectCallbackId));
        });
    }

    private void initMessages() {
        List<Entities.Message> messages = DatabaseHelper.getMessages(roomId);
        Hashtable<Long, Entities.MessageLocal> messageLocals = DatabaseHelper.getLocalMessages(messages);
        Hashtable<Long, Entities.FileLocal> fileLocals = DatabaseHelper.getLocalFiles(messages);
        chatRV.setAdapter(new MessagesAdapter(this, messages, messageLocals, fileLocals));
        chatRV.scrollToPosition(Objects.requireNonNull(chatRV.getAdapter()).getItemCount() - 1);
    }

    public void onToBottomFABClicked(View view) {

    }
}
