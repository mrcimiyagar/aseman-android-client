package kasper.android.pulse.fragments;

import androidx.fragment.app.Fragment;

public abstract class BaseFragment extends Fragment {

}
