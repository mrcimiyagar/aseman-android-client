package kasper.android.pulse.callbacks.network;

/**
 * Created by keyhan1376 on 3/28/2018.
 */

public interface OnAvatarIdEditedListener {
    void onAvatarIdEdited();
}
