package kasper.android.pulse.callbacks.ui;

public interface OnPageTransformListener {

    void run(float previousPagePosition);
}