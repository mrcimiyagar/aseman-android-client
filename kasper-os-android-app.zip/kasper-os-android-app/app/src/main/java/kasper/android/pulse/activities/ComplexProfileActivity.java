package kasper.android.pulse.activities;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.appbar.AppBarLayout;

import java.util.ArrayList;
import java.util.List;

import kasper.android.pulse.R;
import kasper.android.pulse.adapters.RoomsAdapter;
import kasper.android.pulse.callbacks.ui.OnRoomIconClickListener;
import kasper.android.pulse.extras.LinearDecoration;
import kasper.android.pulse.helpers.DatabaseHelper;
import kasper.android.pulse.helpers.GraphicHelper;
import kasper.android.pulse.helpers.NetworkHelper;
import kasper.android.pulse.models.entities.Entities;

public class ComplexProfileActivity extends AppCompatActivity {

    private long complexId;

    private AppBarLayout appBar;
    private Toolbar toolbar;
    private ImageView avatarIV;
    private RecyclerView roomsRV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complex_profile);
        appBar = findViewById(R.id.complexProfileAppBar);
        toolbar = findViewById(R.id.toolbar);
        avatarIV = findViewById(R.id.complexProfileAvatarIV);
        roomsRV = findViewById(R.id.complexProfileRoomsRV);

        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(true);
        }

        if (getIntent().getExtras() != null)
            complexId = getIntent().getExtras().getLong("complex-id");
        roomsRV.setLayoutManager(new LinearLayoutManager(ComplexProfileActivity.this
                , RecyclerView.VERTICAL, false));
        roomsRV.addItemDecoration(new LinearDecoration(GraphicHelper.dpToPx(16), GraphicHelper.dpToPx(88)));

        List<Entities.Room> rooms = new ArrayList<>();

        Entities.Complex complex = DatabaseHelper.getComplexById(complexId);

        for (int counter = 0; counter < 100; counter++) {
            Entities.Room room = new Entities.Room();
            room.setRoomId(counter);
            room.setComplexId(complexId);
            room.setComplex(complex);
            room.setTitle("Hello Room");
            room.setAvatar(0);
            rooms.add(room);
        }

        roomsRV.setAdapter(new RoomsAdapter(this, complexId, rooms, new OnRoomIconClickListener() {
            @Override
            public void roomSelected(Entities.Room room) {

            }
        }));

        /*Entities.Complex complex = DatabaseHelper.getComplexById(complexId);
        fillContent(complex);
        DataSyncer.syncComplexWithServer(complexId, new OnComplexSyncListener() {
            @Override
            public void complexSynced(Entities.Complex complex) {
                fillContent(complex);
            }
            @Override
            public void syncFailed() {
                Toast.makeText(ComplexProfileActivity.this, "Error fetching complex by id", Toast.LENGTH_SHORT).show();
            }
        });
        fillRooms(DatabaseHelper.getRooms(complexId));
        DataSyncer.syncRoomsWithServer(complexId, new OnRoomsSyncListener() {
            @Override
            public void roomsSynced(List<Entities.Room> rooms) {
                fillRooms(rooms);
            }

            @Override
            public void syncFailed() {
                Toast.makeText(ComplexProfileActivity.this, "Error fetching rooms", Toast.LENGTH_SHORT).show();
            }
        });*/
    }

    private void fillContent(Entities.Complex complex) {
        //titleTV.setText(complex.getTitle());
        NetworkHelper.loadComplexAvatar(complex.getAvatar(), avatarIV);
    }

    public void fillRooms(List<Entities.Room> rooms) {
        roomsRV.setAdapter(new RoomsAdapter(this, complexId, rooms, room ->
                startActivity(new Intent(ComplexProfileActivity.this, RoomActivity.class)
                        .putExtra("room_id", room.getRoomId()))));
    }
}
