package kasper.android.pulse.callbacks.network;

/**
 * Created by keyhan1376 on 3/4/2018.
 */

public interface OnRoomDeletedListener {
    void roomDeleted();
}
