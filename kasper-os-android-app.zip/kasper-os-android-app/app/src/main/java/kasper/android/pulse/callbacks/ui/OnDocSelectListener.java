package kasper.android.pulse.callbacks.ui;

import kasper.android.pulse.models.entities.Entities;

/**
 * Created by keyhan1376 on 6/2/2018.
 */

public interface OnDocSelectListener {
    void docLongClicked(Entities.File file);
}
