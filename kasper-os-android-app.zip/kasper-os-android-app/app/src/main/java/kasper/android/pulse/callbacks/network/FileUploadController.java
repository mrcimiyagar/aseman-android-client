package kasper.android.pulse.callbacks.network;

/**
 * Created by keyhan1376 on 5/12/2018.
 */

public interface FileUploadController {
    void cancelUpload();
}
