package kasper.android.pulse.callbacks.ui;

/**
 * Created by keyhan1376 on 5/31/2018.
 */

public interface UiThreadListener {
    void runOnUiThread(Runnable runnable);
}
