package kasper.android.pulse.callbacks.ui;

public interface ObjectListItemClickListener {
    void onItemClicked(int position);
}
