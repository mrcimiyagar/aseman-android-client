package kasper.android.pulse.callbacks.network;

import kasper.android.pulse.models.entities.Entities;

/**
 * Created by keyhan1376 on 3/2/2018.
 */

public interface OnRobotGotListener {
    void botGot(Entities.Bot bot);
}
