package kasper.android.pulse.callbacks.ui;

public interface HomeListener {

}
