package kasper.android.pulse.callbacks.ui;

import kasper.android.pulse.models.entities.Entities;

public interface ProfileListener {
    void profileUpdated(Entities.User user);
}
