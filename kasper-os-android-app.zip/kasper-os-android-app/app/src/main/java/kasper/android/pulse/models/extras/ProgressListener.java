package kasper.android.pulse.models.extras;

public interface ProgressListener {
    void transferred(int progress);
}
