package kasper.android.pulse.behaviors;

public interface IDisposable {
    void dispose();
}
