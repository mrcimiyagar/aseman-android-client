package kasper.android.pulse.callbacks.ui;

public interface ConnectionListener {
    void reconnecting();
    void connected();
}
