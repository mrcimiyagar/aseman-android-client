package kasper.android.pulseframework.models;

public class Exceptions {

    public static class ELangException extends Exception {

    }
}
