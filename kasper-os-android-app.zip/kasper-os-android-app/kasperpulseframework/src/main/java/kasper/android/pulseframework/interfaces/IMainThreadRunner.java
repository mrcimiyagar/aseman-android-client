package kasper.android.pulseframework.interfaces;

public interface IMainThreadRunner {
    void runOnMainThread(Runnable runnable);
}
