package kasper.android.pulseframework.interfaces;

import kasper.android.pulseframework.models.Updates;

public interface IAnimToUpdate {
    void update(Updates.Update update);
}
