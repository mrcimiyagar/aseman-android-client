package kasper.android.pulseframework.interfaces;

import kasper.android.pulseframework.models.Bindings;

public interface IMirrorEffect {
    void mirrorEffect(Bindings.Mirror mirror, Object value);
}
